import React from 'react'
import { RegisterCard } from '../components/Register-Card';

function Register() {

  return (
    <div className='register'>
        <RegisterCard/>
    </div>
  )
}

export default Register